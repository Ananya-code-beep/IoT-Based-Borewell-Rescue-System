# Prototype Photos

Photos of the physical prototype, referenced in Chapter 8 (Results) of the project report:

- `prototype-1.jpeg` – `prototype-9.jpeg`: hardware assembly, internal gripper mechanism, wiring, firmware upload, and full unit views.

Feel free to rename these to something more descriptive (e.g. `full-assembly.jpeg`, `gripper-closeup.jpeg`) once you know which photo is which.
